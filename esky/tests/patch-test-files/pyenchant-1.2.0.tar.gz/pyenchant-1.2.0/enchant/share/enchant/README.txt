
This directory contains dictionary files for Enchant when installed on a
Microsoft Windows system.  Each subdirectory contains dictionaries for
a particular spellchecking system.
